@echo off
chcp 65001 >nul
setlocal EnableExtensions

title Desinstallation MasterMotion
cd /d "%~dp0"

set "UPIA=%CommonProgramFiles%\Adobe\Adobe Desktop Common\RemoteComponents\UPI\UnifiedPluginInstallerAgent\UnifiedPluginInstallerAgent.exe"
set "PLUGIN_ID=com.mastermotion.toolkit"

echo.
echo  ========================================
echo   MasterMotion — Desinstallation
echo  ========================================
echo.

if not exist "%UPIA%" (
  echo  [ERREUR] Adobe UPIA introuvable.
  echo  Desinstallez le plugin depuis Creative Cloud Desktop
  echo  ^(Applications → Modules complémentaires / Plugins^).
  echo.
  pause
  exit /b 1
)

echo  Suppression de %PLUGIN_ID% …
"%UPIA%" /remove "%PLUGIN_ID%"
echo.
echo  Termine. Redemarrez Premiere Pro.
echo.
pause
endlocal
