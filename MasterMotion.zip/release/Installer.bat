@echo off
chcp 65001 >nul
setlocal EnableExtensions

title Installation MasterMotion
cd /d "%~dp0"

set "CCX=%~dp0MasterMotion_premierepro.ccx"
set "UPIA=%CommonProgramFiles%\Adobe\Adobe Desktop Common\RemoteComponents\UPI\UnifiedPluginInstallerAgent\UnifiedPluginInstallerAgent.exe"

echo.
echo  ========================================
echo   MasterMotion — Installation
echo  ========================================
echo.

if not exist "%CCX%" (
  echo  [ERREUR] Fichier introuvable :
  echo  %CCX%
  echo.
  echo  Demandez au fournisseur le dossier "release" complet.
  echo.
  pause
  exit /b 1
)

echo  Fichier du plugin :
echo  %CCX%
echo.

if exist "%UPIA%" (
  echo  Ouverture de l'installeur Adobe Creative Cloud…
  echo  Cliquez sur "Installer" dans la fenetre qui s'ouvre.
  echo.
  "%UPIA%" /doubleClick "%CCX%"
  if errorlevel 1 (
    echo  Nouvelle tentative avec /install…
    "%UPIA%" /install "%CCX%"
  )
) else (
  echo  Creative Cloud Desktop non detecte via UPIA.
  echo  Ouverture directe du fichier .ccx…
  echo  Si rien ne se passe : installez Creative Cloud Desktop,
  echo  puis double-cliquez sur MasterMotion_premierepro.ccx
  echo.
  start "" "%CCX%"
)

echo.
echo  Ensuite dans Premiere Pro 25.6+ :
echo   1. Redemarrez Premiere Pro
echo   2. Menu Fenetre / Plugins  →  MasterMotion
echo.
echo  Installation lancee.
echo.
pause
endlocal
